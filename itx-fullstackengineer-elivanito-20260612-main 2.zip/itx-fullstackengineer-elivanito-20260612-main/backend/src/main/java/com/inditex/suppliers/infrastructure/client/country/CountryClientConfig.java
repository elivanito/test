package com.inditex.suppliers.infrastructure.client.country;

import org.springframework.boot.context.properties.EnableConfigurationProperties;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.web.client.RestClient;

import java.time.Duration;

@Configuration
@EnableConfigurationProperties(CountryServiceProperties.class)
public class CountryClientConfig {

    @Bean
    public RestClient countryRestClient(CountryServiceProperties props) {
        return RestClient.builder()
                .baseUrl(props.getBaseUrl())
                .requestFactory(clientHttpRequestFactory())
                .build();
    }

    private static org.springframework.http.client.ClientHttpRequestFactory clientHttpRequestFactory() {
        var settings = org.springframework.boot.web.client.ClientHttpRequestFactorySettings.DEFAULTS
                .withConnectTimeout(Duration.ofSeconds(1))
                .withReadTimeout(Duration.ofSeconds(2));
        return org.springframework.boot.web.client.ClientHttpRequestFactories.get(settings);
    }
}
