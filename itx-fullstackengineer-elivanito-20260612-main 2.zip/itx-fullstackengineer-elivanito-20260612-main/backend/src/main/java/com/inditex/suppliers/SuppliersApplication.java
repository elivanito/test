package com.inditex.suppliers;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.cache.annotation.EnableCaching;

@SpringBootApplication
@EnableCaching
public class SuppliersApplication {
    public static void main(String[] args) {
        SpringApplication.run(SuppliersApplication.class, args);
    }
}
